THRIFT TO CLOUD - WEBSITE PROTOTYPE

Open index.html in a browser. Demo login: admin@thriftcloud.local / demo1234.

Stock rules: Quantity is the current stock. 0 = Out of Stock and is hidden from the customer store. Quantities from 1 through the minimum stock level are Low Stock. Quantities above the minimum are In Stock. Sales and accepted demo online orders are rejected if requested quantity exceeds available stock. Accepted demo online orders deduct stock and update dashboard alerts.

The dashboard shows in-app low-stock and out-of-stock alerts. Real email or SMS notifications require a backend and a messaging service.

This is a browser-only front-end demonstration. Data is stored in localStorage on this device. It has no shared cloud database, production authentication, or live payment processing. Do not enter real sensitive data.
